import {initializeVoxtersPet} from "./voxters-pet";


export {
    initializeVoxtersPet
}